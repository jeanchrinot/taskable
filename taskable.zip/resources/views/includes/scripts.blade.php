<!-- Jquery Core Js -->
    <script src="/assets/plugins/jquery/dist/jquery.min.js"></script>

    <!-- JQuery UI Js -->
    <script src="/assets/plugins/jquery-ui/jquery-ui.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="/assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Pace Loader Js -->
    <script src="/assets/plugins/pace/pace.js"></script>

    <!-- Screenfull Js -->
    <script src="/assets/plugins/screenfull/src/screenfull.js"></script>

    <!-- Metis Menu Js -->
    <script src="/assets/plugins/metisMenu/dist/metisMenu.js"></script>

    <!-- Jquery Slimscroll Js -->
    <script src="/assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Switchery Js -->
    <script src="/assets/plugins/switchery/dist/switchery.js"></script>

    <!-- iCheck Js -->
    <script src="/assets/plugins/iCheck/icheck.js"></script>

    <!-- Jquery Sparkline Js -->
    <script src="/assets/plugins/jquery-sparkline/dist/jquery.sparkline.js"></script>

    <!-- JQuery Datatables Js -->
    <script src="/assets/plugins/DataTables/media/js/jquery.dataTables.js"></script>
    <script src="/assets/plugins/DataTables/media/js/dataTables.bootstrap.js"></script>
    <script src="/assets/plugins/DataTables/extensions/export/dataTables.buttons.min.js"></script>
    <script src="/assets/plugins/DataTables/extensions/export/buttons.bootstrap.min.js"></script>
    <script src="/assets/plugins/DataTables/extensions/export/buttons.flash.min.js"></script>
    <script src="/assets/plugins/DataTables/extensions/export/vfs_fonts.js"></script>
    <script src="/assets/plugins/DataTables/extensions/export/buttons.html5.min.js"></script>

    <!-- Piety Js -->
    <script src="/assets/plugins/peity/jquery.peity.js"></script>

    <!-- Custom Js -->
    <script src="/assets/js/admin.js"></script>
    <script src="/assets/js/pages/dashboard/dashboard_v2.js"></script>