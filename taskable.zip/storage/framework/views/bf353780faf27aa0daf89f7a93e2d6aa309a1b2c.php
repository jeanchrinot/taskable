
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="dark-bg">
<head>
    <?php echo $__env->yieldContent('head-scripts'); ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- Font Awesome Css -->
    <link href="/assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body class="dark-bg">
    <div class="page-container" id="app">
        <div class="content-wrap">
            <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
                <div class="container">
                    <div class="logo">
                        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img class="logo-img" src="/img/taskable-logo-horizontal.png">
                        </a>
                    </div>
                    
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mr-auto">

                        </ul>

                        <auth-navbar></auth-navbar>
                    </div>
                </div>
            </nav>

            <main>
                 <div class="all-content-wrapper">
                <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
        </div>
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <script src="/assets/plugins/jquery/dist/jquery.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="/assets/plugins/metisMenu/dist/metisMenu.js"></script>
</body>
</html>
<?php /**PATH E:\taskable\resources\views/layouts/app.blade.php ENDPATH**/ ?>