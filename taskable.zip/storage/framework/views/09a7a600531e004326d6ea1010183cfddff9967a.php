<?php $__env->startSection('head-scripts'); ?>
    <script type="text/javascript">
        if (!(localStorage.getItem('userToken'))) {
            window.location.replace('/auth/login');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

        <section class="content">
            <div class="content__header">
                <div class="sidebar__nav__head">
                    <div class="title--small">
                        MAIN NAVIGATION
                    </div>
                    <div class="sidebar__menu__icon sidebar__menu__icon--close-x nav__icon">
                        <span class="sidebar__menu__icon--middle"></span>
                    </div>
                </div>
                <div class="content__title">
                    <h1 class="content__title__text">Profile</h1>
                </div>
            </div>
            <div class="content__main">
                <div class="content__main__left content__main__left--expanded">
                    <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="content__main__right">
                    <div class="row">
                        <!-- <div class="col-md-6 pd-0">
                            <user-profile></user-profile>
                        </div> -->
                        <div class="col-md-12 pd-0">
                            <user-info></user-info>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('includes.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\taskable\resources\views/profile.blade.php ENDPATH**/ ?>