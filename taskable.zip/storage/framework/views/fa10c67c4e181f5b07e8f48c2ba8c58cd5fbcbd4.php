 <div class="footer flex-center">
            <div class="wrapper">
                <div class="links text-center float-left">
                    <a href="#">How to use</a>
                    <a href="#">About</a>
                    <a href="#">Contact us</a>
                    <a href="https://github.com/jeanchrinot/taskable" target="_blank">GitHub</a>
                </div>
                <div class="cr-text text-center text-white float-right">
                    <p>Copyright © 2020 Taskable. All rights reserved.</p>
                </div>
            </div>
    </div><?php /**PATH E:\taskable\resources\views/includes/footer.blade.php ENDPATH**/ ?>