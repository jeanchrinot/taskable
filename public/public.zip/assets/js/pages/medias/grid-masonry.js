﻿(function ($) {
    'use strict';
    $(function () {
        $('.page-body .row').masonry({
            itemSelector: '.col-sm-4'
        });
    });
}(jQuery))
